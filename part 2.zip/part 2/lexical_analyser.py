import re
import pandas as pd

# List of token types
token_types = ['COMMENT', 'Keywords', 'Constants', 'Strings', 'WHITESPACE',
 'INTEGER', 'LPAREN', 'RPAREN', 'PLUS', 'MINUS', 'MULTIPLY', 'DIVIDE', 'COMMA', 'SINGLE_QUOTATION', 'DOUBLE_QUOTATION', 'EQUAL', 'ASSIGNMENT', 'COLON', 'SEMICOLON', 'Identifiers', 'OPERATORS', 'SEPARATORS']

# Regular expressions for each token type
tokens = {
    
    'COMMENT':              r'\#' + r'.*',
    'Keywords':             r'if|else|for|elif|while',
    'Constants':            r'\d+',
    'Strings':              r'".*?"|\'.*?\'',
    'WHITESPACE':           r'\s+',
    'INTEGER':              r'\d+',
    'LPAREN':               r'\(',
    'RPAREN':               r'\)',
    'PLUS':                 r'\+',
    'MINUS':                r'\-',
    'MULTIPLY':             r'\*',
    'DIVIDE':               r'\/',
    'COMMA':                r'\,',
    'SINGLE_QUOTATION':     r'\'',
    'DOUBLE_QUOTATION':     r'\"',
    'EQUAL':                r'==',
    'ASSIGNMENT':           r'=',
    'COLON':                r':',
    'SEMICOLON':            r';',
    'Identifiers':          r'[a-zA-Z_]\w*',
    'OPERATORS':            r'\+|\-|\*|\/|\=|\=,\=',
    'SEPARATORS':           r'\(|\)|\{|\}|\,|\'|\"|\:|\;|\[|\]'

}


    

# Compile regular expressions
for key in tokens:
    tokens[key] = re.compile(tokens[key])

# Read input file
with open('Input.txt', 'r') as f:
    text = f.read()

# Initialize list to hold tokens and token types
output = []

# Iterate through each character in the input text
i = 0
while i < len(text):
    match = None
    for token_type in token_types:
        # Use re.match to find a match at the beginning of the text
        match = tokens[token_type].match(text, i)
        if match:
            output.append((match.group(), token_type))
            i = match.end()
            break
    if not match:
        raise Exception(f'Invalid character: {text[i]}')

# Write output to an Excel file
df = pd.DataFrame(output, columns=['Token', 'Token Type'])
df.to_excel('Output.xlsx', index=False)